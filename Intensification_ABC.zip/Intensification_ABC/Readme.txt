Readme file for ABC of Intensification

CHPC Setup
HPC Cluster: Notchpeak
R version: 4.0.2 Basic packages
Number of Cores: 32 (unless we can use more - if we can use 64 let's do 64, why not)
Memory per job in GB: 64gb Minimum (128gb min if 64 cores) but probably select more if possible (the models seem to fail if there isn't at least 2gb memory per core)

Necessary Folders
Intensification_ABC - main folder with all files
data - folder containing input data read into R for model analysis
Output - folder where simulated outputs are saved as Rdata files

Necessary Files (may need to create/insert the file pathway in the R code for these but they are stored in the data folder)
CHPC_Intensification_ABC.R - this file contains the code to run the simulations, though it calls upon the next two files for specific functions
03_loggrowthmodel.R - this file contains the function for running the logistic population simulation
04_simulatedmodelspds.R - this file contains the function for creating spds from the simulated logistic growth population. It also calculates our initial similarity metrics.
pla.clim.df.csv - this csv file contains the temperature, precip, and NPP data for the Colorado Plateau needed for the model run
bas.clim.df.csv - this csv file contains the temperature, precip, and NPP data for the Great Basin needed for the model run
Observed_spds_Plateau.csv - this csv file contains the 1000 spds we match to from the Colorado Plateau
Observed_spds_Basin.csv - this csv file contains the 1000 spds we match to from the Great Basin
Plateau_errors.csv - this csv contains a vector of radiocarbon date errors used in generating SPDs from the simulated populations for the Colorado Plateau
Basin_errors.csv - this csv contains a vector of radiocarbon date errors used in generating SPDs from the simulated populations for the Great Basin

Keys for model run
1) CHPC_Intensification_ABC.R needs to be able to read/access the other files (source code files 03_loggrowthmodel and 04_simulatedmodelspds as well as the CSVs)
2) File pathways may need to be edited / enterred by you in the R code
3) SLURM code is not yet created - I didn't get a chance to make that with the other things I needed to complete before leaving
4) It will be hard to tell, but when I was running 

Steps for Running
1) Upload the zipped (well unzipped) file folder to Files in On Demand
2) Ensure the file pathways in the uploaded R script (CHPC_Intensification_ABC.R) are correct for where the folder was uploaded
	a) Right now the file pathways are to my CHPC desktop folder (/uufs/chpc.utah.edu/common/home/u1132502/Desktop/Intensification_ABC) - I'm not sure if you will be able
		access files on my drive or not
		i) File pathway calls are made on lines 14,15,20,25,30,34,39,40,163,164,226, & 227
3) Install the packages doParallel, doSNOW, foreach, iterators, rcarbon, snow, spatstat.utils, and truncnorm to the R workspace
4) Set up SLURM call (need to use R version 4.0.2 Basic Packages, 32+ cores, at least 64gb memory per job (maybe more - minimum = number of cores * 2))
	a) If using more than 32 cores, the R code lines 104 and 167 will need to be updated (they currently read ncores <- 32. The 32 would need to be changed to however many cores used)
5) Hit run (or whatever the command call is within the console using SLURM)
6) Begin watching https://www.youtube.com/watch?v=j-LfQCPJJkY and just get lost in finding all the next parody videos
7) Output should dump as an Rdata file into the Output folder already uploaded
8) To confirm if all models at least seemed to have run the following checks could be done:
	a) load the CP_Model_parameter_setups_test.Rdata object into R - it should have 1,000,000 rows and 4010 columns
	b) load the GB_Model_parameter_setups_test.Rdata object into R - it should have 1,000,000 rows and 4010 columns
	c) load the CP_Model_results_test.RData object into R - it should have 1,000,000 rows and 16017 columns
	d) load the GB_Model_results_test.RData object into R - it should have 1,000,000 rows and 16017 columns
Fin) Watch https://www.youtube.com/watch?v=Yz9u-oG3BgM just for one more go at it