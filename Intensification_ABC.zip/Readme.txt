Readme file for ABC of Intensification

CHPC Setup
HPC Cluster: Notchpeak
R version: 4.2.2 CHPC Build
Number of Cores: 32 (unless we can use more - if we can use 64 let's do 64, why not)
Memory per job in GB: 64gb Minimum (128gb min if 64 cores) but probably select more if possible (the models seem to fail if there isn't at least 2gb memory per core)

Necessary Folders
Intensification_ABC - main folder with all files
data - folder containing input data read into R for model analysis
Output - folder where simulated outputs are saved as Rdata files

Necessary Files (may need to create/insert the file pathway in the R code for these but they are stored in the data folder)
Intensification_ABC_SingleModel_Run_arrow.R - this file contains the code to run the simulations, though it calls upon the next two files for specific functions
03_loggrowthmodel.R - this file contains the function for running the logistic population simulation
04_simulatedmodelspds_singlemodel_run_arrow.R - this file contains the function for creating spds from the simulated logistic growth population. It also calculates our initial similarity metrics.
pla.clim.df.Rdata - this data file contains the temperature, precip, and NPP data for the Colorado Plateau needed for the model run
bas.clim.df.Rdata - this data file contains the temperature, precip, and NPP data for the Great Basin needed for the model run
Observed_spds_Plateau.Rdata - this data file contains the 1000 spds we match to from the Colorado Plateau
Observed_spds_Basin.Rdata - this data file contains the 1000 spds we match to from the Great Basin
Plateau_errors.Rdata - this data contains a vector of radiocarbon date errors used in generating SPDs from the simulated populations for the Colorado Plateau
Basin_errors.Rdata - this data contains a vector of radiocarbon date errors used in generating SPDs from the simulated populations for the Great Basin

Keys for model run
1) Intensification_ABC_SingleModel_Run_arrow.R needs to be able to read/access the other files (source code files 03_loggrowthmodel and 04_simulatedmodelspds_singlemodel_run_arrow.R as well as the Rdata files)
2) File pathways may need to be edited / enterred in the R code
3) SLURM code is not yet created


Steps for Running
1) Upload the zipped (well unzipped) file folder to Files in On Demand
2) Ensure the file pathways in the uploaded R script (Intensification_ABC_SingleModel_Run_arrow.R) are correct for where the folder was uploaded
	a) Right now the file pathways are to my CHPC desktop folder (/uufs/chpc.utah.edu/common/home/u1132502/Desktop/Intensification_ABC) - I'm not sure if you will be able
		access files on my drive or not
		i) File pathway calls are made on lines 14,15,20,25,30,34,39,40,163,164,226, & 227
3) Install the packages spatstat.utils, rcarbon, truncnorm, arrow, duckdb, dplyr, tidyr to the R workspace
4) Set up SLURM call (need to use R version 4.2.2 CHPC Build)
5) Hit run (or whatever the command call is within the console using SLURM)
6) Output should dump as an Rdata file into the Output folders

